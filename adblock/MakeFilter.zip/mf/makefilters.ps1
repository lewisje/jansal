# MakeFilters PowerShell Script 1.0
# Chris Renshaw / osmosis 2010

# Automatically downloads the latest EasyList (without element hiding) blocklist for Adblock Plus,
# parses out complex entries, converts it into hexadecimal IE8+ InPrivate Filter registry entry format,
# then writes it to a .reg file for easily importing the new filters.

param([string]$args)
$script:startTime = get-date
write-host "MakeFilters PowerShell Script 1.0`nChris Renshaw / osmosis 2010`n`nPerforming tasks:"

$date = get-date -format 'yyyy-MM-dd'
if (($args) -ne "-forautoupd") { $file = "easylist-adblock_" + $date + ".ini"; $regname = "filter_" + $date + ".reg" }
else { $file,$regname = "easylist-adblock_autoupdate.ini","filter_autoupdate.reg" }

write-host "(1 of 6) Downloading '$file'..."
if ((test-path $file) -eq "True") { write-host "NOTE: '$file' already exists, overwriting..." }
$url = "https://easylist-downloads.adblockplus.org/easylist_noelemhide.txt"
$filepath = join-path $pwd (split-path -leaf $file)
$client = new-object System.Net.WebClient
$client.downloadfile($url,$filepath)

$filters = (type $file) -notmatch "!" -notmatch "\[" -notmatch "@@" -replace "\|","" -replace '\$third-party',"" -replace '\^',"" -replace " ",""
$filters = ($filters | foreach { if ($_.length -igt 1) { $_.trimstart("\*").trimend("\*") } }) -notmatch "\*" -notmatch '\$' -notmatch "~"
$fbcount = ($filters | measure-object).count
$fbchex = ("{0:X}" -f $fbcount).padleft(4,"0")
$fbcreghex = $fbchex.substring(2) + "," + $fbchex.substring(0,2)
write-host "(2 of 6) Filters parsed: $fbcount total 'Block' entries."

$except = (type exceptions.ini) -notmatch "#" -replace " ",""
if ($except -eq "False") { $except = $null }
$facount = ($except | measure-object).count
$fachex = ("{0:X}" -f $facount).padleft(4,"0")
$facreghex = $fachex.substring(2) + "," + $fachex.substring(0,2)
write-host "(3 of 6) Exceptions parsed: $facount total 'Allow' entries."

write-host "(4 of 6) Combining lists to character array..."
$filtersall = [string]::join(" ",($except + $filters))
$OFS = ""
$filterarray = $filtersall.ToCharArray()

write-host "(5 of 6) Converting characters to hexadecimal... (Long...)"
$hex = $facreghex + ",00,00," + $fbcreghex + ",00,00"
foreach ($element in $filterarray) {
$charhex = [System.String]::format("{0:X}", [System.Convert]::ToUInt32($element))
if($charhex -ne "20") { $hex = $hex + "," + $charhex + ",00" }
else { $hex = $hex + ",00,00" }
}
$hex = $hex + ",00,00"

write-host "(6 of 6) Creating Registry File '$regname'..."
if ((test-path $regname) -eq "True") { write-host "NOTE: '$regname' already exists, overwriting..."; rm $regname }

"Windows Registry Editor Version 5.00" | add-content $regname
"" | add-content $regname
"[HKEY_CURRENT_USER\Software\Microsoft\Internet Explorer\Safety\PrivacIE]" | add-content $regname
'"WebFilters"=hex:' + $hex.substring(0,60) + '\' | add-content $regname
$i = 60
while (($i + 75) -ilt $hex.length) { "  " + $hex.substring($i,75) + "\" | add-content $regname; $i = $i + 75 }
"  " + $hex.substring($i) | add-content $regname
write-host "Done!"

$runtime = ($(get-date) - $script:StartTime)
$runtm,$runts = $runtime.minutes,$runtime.seconds
write-host "`nCompleted in $runtm minutes and $runts seconds.`nPress any key to exit..."
if (($args) -ne "-forautoupd") { $x = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") }
